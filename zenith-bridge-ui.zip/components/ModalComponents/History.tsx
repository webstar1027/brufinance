import React from "react";
import Image from "next/image";
import { AiOutlineClose, AiOutlineLink } from "react-icons/ai";

const History = () => {
  return (
    <div className=" flex justify-center items-center h-screen w-full z-0 bg-modal ">
      <div className=" w-full mx-4 lg:w-1/2 xl:w-[800px] h-auto bg-dark_purple shadow-md rounded-md backdrop-blur-sm">
        <div className=" mx-8 py-10 flex flex-col">
          <div className="flex justify-between">
            <div className=" text-center text-lg font-bold ">
              Transfer History
            </div>
            <button className=" justify-self-end">
              <AiOutlineClose fontSize={20} />
            </button>
          </div>
          <div className=" flex justify-between items-center shadow-md bg-gradient-radial rounded-lg p-4 mt-8">
            <div className=" flex justify-center items-center w-full ">
              <Image
                src="/assets/img/icon/ETH1.png"
                alt="Chain logo"
                height={50}
                width={50}
              />
              <div className="text-xs ml-4">
                <div className=" flex">
                  <div>Ethereum Mainnet</div>
                  <div>
                    <AiOutlineLink />
                  </div>
                </div>
                <div className="text-[#9f1239]">-21 USDT</div>
              </div>
            </div>
            <div className=" flex justify-center w-[60%]">
              <Image
                src="/assets/img/icon/arr.svg"
                alt="new"
                height={20}
                width={20}
              />
            </div>
            <div className=" flex items-center w-full ">
              <Image
                src="/assets/img/icon/ETH1.png"
                alt="Chain logo"
                height={50}
                width={50}
              />
              <div className="text-xs ml-4">
                <div className=" flex">
                  <span>Ethereum Mainnet</span>
                  <span>
                    <AiOutlineLink />
                  </span>
                </div>
                <div className="text-[#22c55e]">-21 USDT</div>
              </div>
            </div>
            <div className=" w-[60%]  text-xs ">
              <div className="text-[#22c55e] text-right">Completed</div>
              <div className=" text-right">2022-10-04 10:41:33</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default History;
