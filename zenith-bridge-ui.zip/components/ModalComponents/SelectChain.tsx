import React from "react";
import Image from "next/image";
import Link from "next/link";
import { AiOutlineClose } from "react-icons/ai";

interface option {
  name: string;
  value: string;
  label: string;
  icon: string;
}

interface Props {
  options: option[];
  id: option;
  closeModal: React.Dispatch<React.SetStateAction<boolean>>;
  setChainId: React.Dispatch<React.SetStateAction<number>>;
}

const SelectChain = ({ options, id, closeModal, setChainId }: Props) => {
  //   const chains = options.filter((opt) => opt.value !== id.value);

  return (
    <div className="flex justify-center items-center h-screen w-screen z-0 bg-modal">
      <div className=" w-full mx-4 lg:w-1/2 xl:w-[800px] h-auto bg-dark_purple shadow-md rounded-md backdrop-blur-sm">
        <div className="mx-8 py-10 flex flex-col">
          <div className="flex justify-between">
            <div className=" text-center text-lg font-bold ">
              Select Source Chain
            </div>
            <button
              onClick={() => closeModal(false)}
              className="justify-self-end"
            >
              <AiOutlineClose fontSize={20} />
            </button>
          </div>
          <div>
            <input
              type="text"
              placeholder="Search chain by name or chain ID"
              className=" py-4 px-8 bg-dark rounded-3xl w-full mt-16 outline-none focus:outline-none "
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-6 mt-10">
            {options.map((option, i) => (
              <button
                key={`bu-${i}`}
                onClick={() => {
                  setChainId(+option.value), closeModal(false);
                }}
                className=" flex items-center shadow-md bg-gradient-radial rounded-lg p-4 cursor-pointer"
              >
                <Image
                  src={option.icon}
                  alt="WalletConnect"
                  height={30}
                  width={30}
                />
                <p className=" ml-2">{option.label}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelectChain;
