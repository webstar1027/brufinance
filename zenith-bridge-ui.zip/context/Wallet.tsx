import React, {
  createContext,
  ReactNode,
  useCallback,
  useEffect,
  useState,
} from "react";

export const WalletContext = createContext({});

export type WalletProviderProps = { children?: ReactNode };

export function WalletProvider({ children }: WalletProviderProps) {
  const [categories, setCategories] = useState([]);

  return (
    <WalletContext.Provider value={{ categories }}>
      {children}
    </WalletContext.Provider>
  );
}
