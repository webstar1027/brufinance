interface Log {
  address: string;
  topics: string[];
  data: string;
  blockNumber: number;
  transactionHash: string;
  transactionIndex: number;
  blockHash: string;
  logIndex: number;
  removed: boolean;
  id: string;
}

interface MintReceipt {
  blockHash: string;
  blockNumber: number;
  contractAddress?: any;
  cumulativeGasUsed: number;
  effectiveGasPrice: number;
  from: string;
  gasUsed: number;
  logs: Log[];
  logsBloom: string;
  status: boolean;
  to: string;
  transactionHash: string;
  transactionIndex: number;
  type: string;
}

interface RootObject {
  transactionHash: string;
  status: string;
  mintReceipt: MintReceipt;
}
