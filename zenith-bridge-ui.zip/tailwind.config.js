/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      backgroundImage: {
        "gradient-radial":
          "radial-gradient(111.14% 111.14% at 8.37% 0%, rgba(255, 255, 255, 0.144) 0%, rgba(255, 255, 255, 0) 100%)",
        "gradient-linear": "linear-gradient(90deg, #3407DE 0%, #744FFF 100%)",
      },
    },
    colors: {
      dark: "#0F0F0F",
      dark_purple: "#050311",
      modal: "rgba(0, 0, 0, 0.5)",
    },
  },
  plugins: [],
};
