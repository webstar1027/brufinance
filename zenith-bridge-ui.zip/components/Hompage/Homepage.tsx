import React, { useEffect, useState } from "react";
import { AiOutlineInfoCircle, AiOutlineDown } from "react-icons/ai";
import { useWeb3React } from "@web3-react/core";
import Image from "next/image";
import SelectChain from "../ModalComponents/SelectChain";
import SelectToken from "../ModalComponents/SelectToken";
import AwaitingConfirmation from "../ModalComponents/AwaitingConfirmation";
import TransactionCompleted from "../ModalComponents/TransactionCompleted";
import TransactionFailed from "../ModalComponents/TransactionFailed";
import { networks } from "../../utils/network";
import { getTokenBalance } from "../../utils/utils";
import { sendSwapReceipt, sendBurnReceipt } from "../../utils/utils";
import PendingConfirmation from "../ModalComponents/PendingConfirmation";

const options = [
  // {
  //   name: "ethereum",
  //   value: "1",
  //   label: "Ethereum Mainnet",
  //   icon: "/assets/img/icon/ETH1.png",
  // },
  {
    name: "goerli",
    value: "5",
    label: "Ethereum Testnet Görli",
    icon: "/assets/img/icon/ETH1.png",
  },
  {
    name: "zenith",
    value: "79",
    label: "Zenith Chain",
    icon: "/assets/img/icon/Zenith.svg",
  },
];

const tokens = [
  {
    name: "usdt",
    value: "1",
    label: "Tether USD",
    icon: "/assets/img/icon/usdt.png",
  },
  {
    name: "usdc",
    value: "2",
    label: "USD Coin",
    icon: "/assets/img/icon/usdc.png",
  },
];

const Homepage = () => {
  const { library, chainId, account, active } = useWeb3React();
  const [modalOpen, setModalOpen] = useState(false);
  const [token, setToken] = useState(tokens[0].value);
  const [tokenModalOpen, setTokenModalOpen] = useState(false);
  const [source, setSource] = useState("from");
  const [chainMatch, setChainMatch] = useState(false);
  const [amount, setAmount] = useState("0.1");
  const [max, setMax] = useState<any>(0);
  const [loading, setLoading] = useState(false);
  const [swap, setSwap] = useState(false);
  const [tnxData, setTnxData] = useState<RootObject | null>();
  const [sourceChainId, setSourceChainId] = useState(+options[0].value);
  const [destinationChainId, setDestinationChainId] = useState(
    +options[1].value
  );

  const sourceChain = options.find((opt) => +opt.value === sourceChainId);
  const destinationChain = options.find(
    (opt) => +opt.value === destinationChainId
  );
  const selectedToken = tokens.find((coin) => coin.value === token);

  const usdtTokenAddress = "0x97e43D365D545c63B5039c4fB9aac5D5D4a16110";
  const usdtBrigdeAddress = "0x74660AFF9e3e448194F87e543c46e055072f3F54";

  const usdcTokenAddress = "0xaE07F294B7f4F6237DcB6c956de114dA70613F07";
  const usdcBrigdeAddress = "0x5AdA91d710f246244AE4131a43F662EB4E7E8516";

  const zenUsdtTokenAddress = "0x5aD4F218871A2Ed615C02D1c7aCE757D3De2f793";
  const zenUsdcTokenAddress = "0x0850Be42C30703b1C165899800BD60aA81bA9F25";

  useEffect(() => {
    if (sourceChainId === +options[0].value) {
      setDestinationChainId(+options[1].value);
    } else {
      setDestinationChainId(+options[0].value);
    }
  }, [sourceChainId, destinationChainId]);

  useEffect(() => {
    if (chainId !== sourceChainId) {
      setChainMatch(false);
    } else {
      setChainMatch(true);
    }
  }, [chainId, sourceChainId]);

  useEffect(() => {
    if (
      chainId === sourceChainId &&
      sourceChain.name === "goerli" &&
      selectedToken.name === "usdt"
    ) {
      // getTokenBalance(library, account, usdtTokenAddress).then((data) =>
      //   setMax(data)
      // );
    } else if (
      chainId === sourceChainId &&
      sourceChain.name === "goerli" &&
      selectedToken.name === "usdc"
    ) {
      getTokenBalance(library, account, usdcTokenAddress).then((data) =>
        setMax(data)
      );
    } else if (
      chainId === sourceChainId &&
      sourceChain.name === "zenith" &&
      selectedToken.name === "usdt"
    ) {
      getTokenBalance(library, account, zenUsdtTokenAddress).then((data) =>
        setMax(data)
      );
    } else if (
      chainId === sourceChainId &&
      sourceChain.name === "zenith" &&
      selectedToken.name === "usdc"
    ) {
      getTokenBalance(library, account, zenUsdcTokenAddress).then((data) =>
        setMax(data)
      );
    } else {
      return;
    }
  });

  const handleNetworkSwitch = async (name: string) => {
    try {
      await library._provider.request({
        method: "wallet_addEthereumChain",
        params: [
          {
            ...networks[name],
          },
        ],
      });
    } catch (switchError) {
      if (switchError.code === -32602) {
        try {
          await library._provider.request({
            method: "wallet_switchEthereumChain",
            params: [{ ...networks[name] }],
          });
        } catch (error) {
          console.log(error.message);
        }
      }
    }
  };

  const waitForApproveReceipt = async (txhash) => {
    library.eth.getTransactionReceipt(txhash, (err, receipt) => {
      if (err) {
        console.log(err);
      }
      if (receipt !== null) {
        console.log(receipt);
        setSwap(true);
        setLoading(false);
      } else {
        // Try again in 1 second
        window.setTimeout(function () {
          waitForApproveReceipt(txhash);
        }, 1000);
      }
    });
  };

  const waitForSwapReceipt = async (txhash, type: string) => {
    const token = type === "usdt" ? "USDT" : "USDC";

    const receipt = await library.eth.getTransactionReceipt(
      txhash,
      (err, receipt) => {
        if (err) {
          console.log(err);
        }
        if (receipt !== null) {
          return receipt;
        } else {
          // Try again in 1 second
          window.setTimeout(function () {
            waitForSwapReceipt(txhash, type);
          }, 1000);
        }
      }
    );

    if (receipt) {
      const data = await sendSwapReceipt({
        cryptocurrency: token,
        receipt,
      });
      setSwap(false);
      setLoading(false);
      setTnxData(data);
      console.log(data);
    }
  };

  const waitForBurnReceipt = async (txhash, type: string) => {
    const token = type === "usdt" ? "USDT" : "USDC";

    const receipt = await library.eth.getTransactionReceipt(
      txhash,
      (err, receipt) => {
        if (err) {
          console.log(err);
        }
        if (receipt !== null) {
          return receipt;
        } else {
          // Try again in 1 second
          window.setTimeout(function () {
            waitForBurnReceipt(txhash, type);
          }, 1000);
        }
      }
    );

    if (receipt) {
      const data = await sendBurnReceipt({
        cryptocurrency: token,
        receipt,
      });
      setSwap(false);
      setLoading(false);
      setTnxData(data);
      console.log(data);
    }
  };

  const handleApprove = () => {
    // if (+amount <= +max) {
    setLoading(true);
    const amountToApprove = library.utils.toWei(amount);
    const methodSign = library.eth.abi.encodeFunctionCall(
      {
        name: "approve",
        type: "function",
        inputs: [
          {
            type: "address",
            name: "spender",
          },
          {
            type: "uint256",
            name: "amount",
          },
        ],
      },
      [
        selectedToken.name === "usdt" ? usdtBrigdeAddress : usdcBrigdeAddress,
        amountToApprove,
      ]
    );

    let transactionParam = {
      to: selectedToken.name === "usdt" ? usdtTokenAddress : usdcTokenAddress,
      amountToApprove,
      from: account,
      value: "0x0",
      data: methodSign,
      // gasPrice: 10000000000000,
      // gas: 10000000000000,
    };

    library._provider
      .request({
        method: "eth_sendTransaction",
        id: 1,
        jsonrpc: "2.0",
        params: [transactionParam],
      })
      .then((txhash) => {
        waitForApproveReceipt(txhash);
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
      });
    // } else {
    //   alert("insufficient Funds");
    // }
  };

  const handleSwap = () => {
    setLoading(true);
    const amountToApprove = library.utils.toWei(amount);
    const methodSign = library.eth.abi.encodeFunctionCall(
      {
        name: "swap",
        type: "function",
        inputs: [
          {
            type: "uint256",
            name: "_amount",
          },
        ],
      },
      [amountToApprove]
    );

    let transactionParam = {
      to: selectedToken.name === "usdt" ? usdtBrigdeAddress : usdcBrigdeAddress, // usdt bridge contract address
      from: account,
      value: "0x0",
      data: methodSign,
      // gasPrice: 10000000000000,
      // gas: 10000000000000,
    };

    library._provider
      .request({
        method: "eth_sendTransaction",
        id: 1,
        jsonrpc: "2.0",
        params: [transactionParam],
      })
      .then(async (txhash) => {
        waitForSwapReceipt(txhash, selectedToken.name);
        setAmount("0.0");
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
      });
  };

  const handleBurn = () => {
    if (+amount <= +max) {
      setLoading(true);
      const amountToBurn = library.utils.toWei(amount);
      const methodSign = library.eth.abi.encodeFunctionCall(
        {
          name: "burn",
          type: "function",
          inputs: [
            {
              type: "uint256",
              name: "_amount",
            },
          ],
        },
        [amountToBurn]
      );

      let transactionParam = {
        to:
          selectedToken.name === "usdt"
            ? zenUsdtTokenAddress
            : zenUsdcTokenAddress, // usdt bridge contract address
        from: account,
        value: "0x0",
        data: methodSign,
        // gasPrice: 10000000000000,
        // gas: 10000000000000,
      };

      library._provider
        .request({
          method: "eth_sendTransaction",
          id: 1,
          jsonrpc: "2.0",
          params: [transactionParam],
        })
        .then((txhash) => {
          waitForBurnReceipt(txhash, selectedToken.name);
        })
        .catch((err) => {
          console.log(err);
          setLoading(false);
        });
    } else {
      alert("insufficient Funds");
    }
  };

  if (modalOpen && source === "from") {
    return (
      <SelectChain
        options={options}
        closeModal={setModalOpen}
        setChainId={setSourceChainId}
        id={sourceChain!}
      />
    );
  } else if (modalOpen && source === "to") {
    return (
      <SelectChain
        options={options}
        closeModal={setModalOpen}
        setChainId={setDestinationChainId}
        id={destinationChain!}
      />
    );
  }

  if (tokenModalOpen) {
    return (
      <SelectToken
        tokens={tokens}
        closeModal={setTokenModalOpen}
        setToken={setToken}
      />
    );
  }

  if (loading) {
    return <AwaitingConfirmation />;
  }

  if (tnxData) {
    if (tnxData.status === "TRANSFER_COMPLETED") {
      return <TransactionCompleted tnxData={tnxData} setTnxData={setTnxData} />;
    } else if (tnxData.status === "PENDING_CONFiRMATION") {
      return (
        <PendingConfirmation
          amount={amount}
          token={selectedToken.name}
          setTnxData={setTnxData}
        />
      );
    } else {
      return (
        <TransactionFailed
          amount={amount}
          token={selectedToken.name}
          setTnxData={setTnxData}
        />
      );
    }
  }

  return (
    <div className="flex justify-center items-center p-28">
      <div className=" w-full mx-4 lg:w-1/2 xl:w-[800px] h-auto bg-dark_purple md:bg-gradient-radial rounded-lg backdrop-blur-sm ">
        <div className=" mx-5 my-6 flex flex-col">
          <div className=" flex items-center">
            <p className=" text-base leading-5 tracking-wide mr-4">From</p>
            <button
              onClick={() => {
                setModalOpen(true);
                setSource("from");
              }}
              className=" bg-dark px-4 py-2 rounded-lg flex items-center"
            >
              <div className=" mr-2 -mb-2">
                <Image
                  src={sourceChain!.icon}
                  alt="WalletConnect"
                  height={30}
                  width={30}
                />
              </div>
              <div className=" mr-2">{sourceChain?.label}</div>
              <div>
                <AiOutlineDown />
              </div>
            </button>
          </div>
          <div className=" w-[98%] mt-6 mx-auto h-28 bg-dark rounded-xl flex flex-col justify-between ">
            <div className=" flex justify-between py-4 mx-4 opacity-70 text-sm leading-4 tracking-wide">
              <div>Send:</div>
              <div className=" border-b pb-1 px-2 ">Max: {max} </div>
            </div>
            <div className=" flex justify-between pb-4 mx-4">
              <input
                placeholder="0.1"
                type="number"
                step="0.01"
                className=" bg-dark w-1/2 p-1 outline-none focus:outline-none rounded-md "
                max={+max}
                min={0.1}
                disabled={swap}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <button
                onClick={() => {
                  setTokenModalOpen(true);
                }}
                className=" bg-dark px-4 py-2 rounded-lg flex items-center"
              >
                <div className=" mr-2 -mb-2">
                  <Image
                    src={selectedToken!.icon}
                    alt={selectedToken!.label}
                    height={30}
                    width={30}
                  />
                </div>
                <div className=" mr-2">{selectedToken?.label}</div>
                <div>
                  <AiOutlineDown />
                </div>
              </button>
            </div>
          </div>
          <button
            onClick={() => {
              setSourceChainId(destinationChainId),
                setDestinationChainId(sourceChainId);
            }}
            className=" self-center my-4 cursor-pointer"
          >
            <Image
              width={30}
              height={30}
              src="/assets/img/icon/swap.svg"
              alt="swap"
            />
          </button>
          <div className=" flex">
            <p className="text-base leading-5 tracking-wide mr-4">To</p>
            <button
              onClick={() => {
                setModalOpen(true);
                setSource("to");
              }}
              className=" bg-dark px-4 py-2 rounded-lg flex items-center"
              disabled={true}
            >
              <div className=" mr-2 -mb-2">
                <Image
                  src={destinationChain!.icon}
                  alt="WalletConnect"
                  height={30}
                  width={30}
                />
              </div>
              <div className=" mr-2">{destinationChain?.label}</div>
              <div>
                <AiOutlineDown />
              </div>
            </button>
          </div>
          <div className=" w-[98%] mt-6 mx-auto h-28 bg-dark rounded-xl flex flex-col justify-between ">
            <div className=" flex py-4 mx-4 items-center opacity-70 ">
              <AiOutlineInfoCircle />
              <p className=" ml-1 text-sm leading-4 tracking-wide">
                Receive (estimated):
              </p>
            </div>
            <div className=" py-4 mx-4 w-full">{amount}</div>
          </div>
          {chainMatch ? (
            swap ? (
              <button
                onClick={handleSwap}
                className=" mt-10 rounded bg-gradient-linear py-4 text-xl leading-7 tracking-wide disabled:cursor-not-allowed disabled:opacity-75"
                disabled={loading}
              >
                {loading ? "Awaiting Confirmation" : "Swap"}
              </button>
            ) : sourceChain.name === "zenith" ? (
              <button
                onClick={handleBurn}
                className=" mt-10 rounded bg-gradient-linear py-4 text-xl leading-7 tracking-wide disabled:cursor-not-allowed disabled:opacity-75"
                disabled={loading}
              >
                {loading ? "Awaiting Confirmation" : "Swap"}
              </button>
            ) : (
              <button
                onClick={handleApprove}
                className=" mt-10 rounded bg-gradient-linear py-4 text-xl leading-7 tracking-wide disabled:cursor-not-allowed disabled:opacity-75"
                disabled={loading}
              >
                {loading ? "Awaiting Confirmation" : "Approve"}
              </button>
            )
          ) : (
            <button
              onClick={() => {
                handleNetworkSwitch(sourceChain?.name!);
              }}
              className=" mt-10 rounded bg-gradient-linear py-4 text-xl leading-7 tracking-wide"
            >
              Switch to {sourceChain?.label}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Homepage;
