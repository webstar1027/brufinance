import { InjectedConnector } from "@web3-react/injected-connector";
import { WalletConnectConnector } from "@web3-react/walletconnect-connector";

const injected = new InjectedConnector({
  supportedChainIds: [1, 3, 4, 5, 42, 79],
});

const walletconnect = new WalletConnectConnector({
  bridge: "https://bridge.walletconnect.org",
  infuraId: "6a057814fde640e19d193bd694815cf4",
  supportedChainIds: [1, 3, 4, 5, 42, 79],
  rpc: {
    5: "https://goerli.infura.io/v3/6a057814fde640e19d193bd694815cf4",
    79: "https://dataserver-asia-3.zenithchain.co/",
  },
});

export const connectors = {
  injected: injected,
  walletConnect: walletconnect,
};
