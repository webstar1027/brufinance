import React from "react";
import Image from "next/image";
import { AiOutlineClose } from "react-icons/ai";

interface Props {
  amount: string;
  token: string;
  setTnxData: React.Dispatch<React.SetStateAction<RootObject>>;
}

const TransactionFailed = ({ amount, token, setTnxData }: Props) => {
  return (
    <div className="flex justify-center items-center h-screen z-0 bg-modal px-8">
      <div className="flex items-center flex-col bg-dark_purple rounded-md shadow-md w-full md:w-3/5 md relative">
        <div className=" flex">
          <h3 className=" text-lg pt-6 text-[#f43f5e]">Transfer Failed!</h3>
          <button
            className=" absolute right-[20px] top-[20px]"
            onClick={() => setTnxData(null)}
          >
            <AiOutlineClose fontSize={20} />
          </button>
        </div>
        <p className="text-xs pb-6">
          {`${amount} ${token} will be returned to your address shortly`}
        </p>
        <Image
          src="/assets/img/icon/close.png"
          alt="check"
          height={100}
          width={100}
        />
        <p className=" text-xs py-6 ">Please try again</p>
      </div>
    </div>
  );
};

export default TransactionFailed;
