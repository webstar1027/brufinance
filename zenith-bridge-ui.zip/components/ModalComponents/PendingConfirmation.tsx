import React from "react";
import Image from "next/image";
import { AiOutlineClose } from "react-icons/ai";

interface Props {
  amount: string;
  token: string;
  setTnxData: React.Dispatch<React.SetStateAction<RootObject>>;
}

const PendingConfirmation = ({ amount, token, setTnxData }: Props) => {
  return (
    <div className="flex justify-center items-center h-screen z-0 bg-modal px-8">
      <div className="flex items-center flex-col bg-dark_purple rounded-md shadow-md w-full  lg:w-3/5 relative">
        <div className=" flex">
          <h3 className=" text-lg py-6">Pending Confirmation</h3>
          <button
            className=" absolute right-[20px] top-[20px]"
            onClick={() => setTnxData(null)}
          >
            <AiOutlineClose fontSize={20} />
          </button>
        </div>
        <Image
          src="/assets/img/icon/wall-clock.png"
          alt="check"
          height={100}
          width={100}
        />
        <p className=" text-xs py-6 ">
          Please Note that transaction may still be rejected and {amount}{" "}
          {token} will be refunded back to you.
        </p>
      </div>
    </div>
  );
};

export default PendingConfirmation;
