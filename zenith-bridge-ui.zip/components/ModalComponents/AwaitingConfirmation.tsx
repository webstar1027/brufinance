import React from "react";
import { ThreeDots } from "react-loader-spinner";

const AwaitingConfirmation = () => {
  return (
    <div className="flex justify-center items-center h-screen z-0 bg-modal">
      <div className="flex items-center flex-col bg-dark_purple rounded-md shadow-md h-52 w-full md:w-2/5">
        <h3 className=" text-lg py-8">Awaiting Confirmation</h3>
        <ThreeDots
          height="80"
          width="80"
          radius="9"
          color="#744FFF"
          ariaLabel="three-dots-loading"
          wrapperStyle={{}}
          visible={true}
        />
      </div>
    </div>
  );
};

export default AwaitingConfirmation;
