export const networks = {
  // ethereum: {
  //   chainId: `0x${Number(1).toString(16)}`,
  //   chainName: "Ethereum Mainnet",
  //   nativeCurrency: {
  //     name: "Ether",
  //     symbol: "ETH",
  //     decimals: 18,
  //   },
  //   rpcUrls: ["https://eth-mainnet.rpcfast.com"],
  //   blockExplorerUrls: ["https://etherscan.io"],
  // },

  goerli: {
    chainId: `0x${Number(5).toString(16)}`,
    chainName: "Ethereum Testnet Görli",
    nativeCurrency: {
      name: "Görli Ether",
      symbol: "ETH",
      decimals: 18,
    },
    rpcUrls: [
      "https://rpc.ankr.com/eth_goerli",
      "https://eth-goerli.public.blastapi.io",
    ],
    blockExplorerUrls: ["https://goerli.etherscan.io"],
  },

  zenith: {
    chainId: `0x${Number(79).toString(16)}`,
    chainName: "Zenith Mainnet",
    nativeCurrency: {
      name: "ZENITH",
      symbol: "ZENITH",
      decimals: 18,
    },
    rpcUrls: [
      "https://dataserver-us-1.zenithchain.co/",
      "https://dataserver-asia-3.zenithchain.co/",
      "https://dataserver-asia-4.zenithchain.co/",
      "https://dataserver-asia-2.zenithchain.co/",
      "https://dataserver-asia-5.zenithchain.co/",
      "https://dataserver-asia-6.zenithchain.co/",
      "https://dataserver-asia-7.zenithchain.co/",
    ],
    blockExplorerUrls: ["https://scan.zenithchain.co"],
  },
};
