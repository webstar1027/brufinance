import type { NextPage } from "next";
import { useState, useEffect } from "react";
import Homepage from "../components/Hompage/Homepage";
import ConnectWallet from "../components/ModalComponents/ConnectWallet";
import SelectChain from "../components/ModalComponents/SelectChain";
import SelectToken from "../components/ModalComponents/SelectToken";
import History from "../components/ModalComponents/History";
import { useWeb3React } from "@web3-react/core";
import { connectors } from "../components/Wallet/connectors";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import TransactionFailed from "../components/ModalComponents/TransactionFailed";
import PendingConfirmation from "../components/ModalComponents/PendingConfirmation";
const Home: NextPage = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const { library, activate, deactivate, active } = useWeb3React();

  useEffect(() => {
    const provider = window.localStorage.getItem("provider");
    if (provider === "injected") {
      activate(connectors.injected);
    } else if (provider === "walletConnect") {
      activate(connectors.walletConnect);
    }
  }, []);

  return (
    <>
      <Header />

      {active ? <Homepage /> : <ConnectWallet />}
      <Footer />
    </>
  );
};

export default Home;
