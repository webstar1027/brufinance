import React from "react";
import Image from "next/image";
import { AiOutlineClose } from "react-icons/ai";

interface Props {
  tnxData: RootObject;
  setTnxData: React.Dispatch<React.SetStateAction<RootObject>>;
}

const TransactionCompleted = ({ tnxData, setTnxData }: Props) => {
  return (
    <div className="flex justify-center items-center h-screen z-0 bg-modal px-8">
      <div className="flex items-center flex-col bg-dark_purple rounded-md shadow-md w-full  lg:w-3/5 relative">
        <div className=" flex">
          <h3 className=" text-lg py-6">Transfer Complete</h3>
          <button
            className=" absolute right-[20px] top-[20px]"
            onClick={() => setTnxData(null)}
          >
            <AiOutlineClose fontSize={20} />
          </button>
        </div>
        <Image
          src="/assets/img/icon/checked.png"
          alt="check"
          height={100}
          width={100}
        />
        <p className=" text-xs py-6 ">
          <a
            href={`https://scan.zenithchain.co/tx/${tnxData?.transactionHash}`}
            className=" text-[#2563eb]"
          >
            View transaction on Zenith Scan
          </a>
        </p>
        {/* <p className=" text-xs pt-2 pb-6 ">
          <span>Mint Hash: </span>
          <span className="">{tnxData?.mintReceipt?.transactionHash}</span>
        </p> */}
      </div>
    </div>
  );
};

export default TransactionCompleted;
