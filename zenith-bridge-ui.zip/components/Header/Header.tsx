import React from "react";
import Link from "next/link";
import Image from "next/image";
import { useWeb3React } from "@web3-react/core";
import { truncateAddress } from "../../utils/utils";

const Header = () => {
  const { account, active, deactivate } = useWeb3React();
  return (
    <div className=" flex justify-between items-center ">
      <div className=" ml-8 mt-4">
        <Link href="#">
          <Image
            src="/assets/img/logo/logo.png"
            alt="zenith logo"
            width={70}
            height={20}
          />
        </Link>
      </div>
      <div className=" flex items-center mr-8 mt-4">
        <button className=" bg-gradient-radial px-4 py-2 rounded-lg md:mr-4">
          <span className=" mr-2">
            <Image
              src="/assets/img/icon/history.svg"
              alt="history"
              width={15}
              height={15}
            />
          </span>
          <span className=" tracking-wide text-base font-semibold ">
            History
          </span>
        </button>
        {active ? (
          <>
            <div className=" bg-gradient-linear px-4 py-2 rounded-lg md:flex items-center mr-4 hidden ">
              <div className=" bg-[#22c55e] w-2 h-2  rounded-full font-bold mr-2"></div>
              <span className=" text-xs">{truncateAddress(account!)}</span>
            </div>
            <button
              className=" bg-gradient-linear px-4 py-2 rounded-lg md:flex items-center hidden "
              onClick={() => deactivate()}
            >
              Disconnect
            </button>
          </>
        ) : (
          <div className=" bg-gradient-linear px-4 py-2 rounded-lg md:flex items-center hidden ">
            <div className=" bg-[#c52522] w-2 h-2  rounded-full font-bold mr-2"></div>
            <span className=" text-xs">No wallet found</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;
