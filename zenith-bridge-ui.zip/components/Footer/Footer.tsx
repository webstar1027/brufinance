import React from "react";
import Link from "next/link";
import {
  AiFillHome,
  AiFillFileText,
  AiOutlineTwitter,
  AiFillGithub,
} from "react-icons/ai";
import { FaDiscord, FaTelegramPlane } from "react-icons/fa";

const links = [
  {
    url: "#",
    icon: <AiFillHome />,
  },

  {
    url: "#",
    icon: <AiFillFileText />,
  },
  {
    url: "#",
    icon: <FaDiscord />,
  },
  {
    url: "#",
    icon: <FaTelegramPlane />,
  },
  {
    url: "#",
    icon: <AiOutlineTwitter />,
  },
  {
    url: "#",
    icon: <AiFillGithub />,
  },
];

const Footer = () => {
  return (
    <footer className=" flex flex-col items-center py-8 ">
      <p className=" text-sm font-medium opacity-70">Powered by Zenith chain</p>
      <div className=" mt-8 flex w-[95%] sm:w-[70%] md:w-1/2 lg:w-[30%] justify-between">
        {links.map((link, i) => (
          <Link href={link.url} key={`li-${i}`}>
            <a className=" p-4 rounded-full bg-dark">{link.icon}</a>
          </Link>
        ))}
      </div>
      <div className=" flex mt-8 text-xs font-medium tracking-wide">
        <div className=" mr-4 underline">
          <a href="#">Contact Support</a>
        </div>
        <div className=" underline">
          <a href="#">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
