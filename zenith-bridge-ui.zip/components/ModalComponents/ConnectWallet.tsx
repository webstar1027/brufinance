import React, { useState } from "react";
import Image from "next/image";
import { useWeb3React } from "@web3-react/core";
import { connectors } from "../Wallet/connectors";
import { AiOutlineClose } from "react-icons/ai";

const ConnectWallet = () => {
  const { activate } = useWeb3React();

  const setProvider = (type: string) => {
    window.localStorage.setItem("provider", type);
  };

  const connect = async (provider: any) => {
    if (window.ethereum) {
      activate(provider);
    } else {
      alert("Please install metamask extension");
    }
  };

  return (
    <div className=" flex justify-center items-center h-screen w-screen z-0 bg-modal ">
      <div className=" w-full mx-4 lg:w-1/2 xl:w-[800px] bg-dark_purple shadow-md rounded-md backdrop-blur-sm">
        <div className=" mx-8 py-10 flex flex-col">
          <div className="flex justify-between">
            <div className=" text-center text-lg font-bold ">
              Connect Your Wallet
            </div>
            {/* <button className=" justify-self-end">
              <AiOutlineClose fontSize={20} />
            </button> */}
          </div>

          <button
            onClick={() => {
              connect(connectors.injected);
              setProvider("injected");
            }}
            className=" bg-gradient-radial rounded-md mt-16 flex justify-between items-center cursor-pointer"
          >
            <div className=" flex items-center p-4">
              <Image
                src="/assets/img/icon/metamask.png"
                alt="Metamask Logo"
                height={50}
                width={50}
              />
              <p className=" ml-4 text-base tracking-wide">Metamask</p>
            </div>
            <div className=" p-4">
              <Image
                src="/assets/img/icon/arrow.svg"
                alt="arr"
                height={20}
                width={20}
              />
            </div>
          </button>
          <button
            onClick={() => {
              activate(connectors.walletConnect);
              setProvider("walletConnect");
            }}
            className=" bg-gradient-radial rounded-md mt-8 flex justify-between items-center cursor-pointer"
          >
            <div className=" flex items-center p-4">
              <Image
                src="/assets/img/icon/wallet_connect.svg"
                alt="WalletConnect Logo"
                height={50}
                width={50}
              />
              <p className=" ml-4 text-base tracking-wide">WalletConnect</p>
            </div>
            <div className=" p-4">
              <Image
                src="/assets/img/icon/arrow.svg"
                alt="arr"
                height={20}
                width={20}
              />
            </div>
          </button>
          <div className=" text-center font-medium text-sm tracking-wide mt-16">
            <span>By connecting. I accept&nbsp;</span>
            <span>
              <a className=" text-[#8247E5]" href="#">
                Terms of use
              </a>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectWallet;
