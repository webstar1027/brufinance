import axios, { AxiosError } from "axios";

export const truncateAddress = (address: string) => {
  const match = address.match(
    /^(0x[a-zA-Z0-9]{2})[a-zA-Z0-9]+([a-zA-Z0-9]{2})$/
  );
  if (!match) return address;
  return `${match[1]}…${match[2]}`;
};

export const getTokenBalance = async (
  library,
  account: string,
  address: string
) => {
  let minABI = [
    // balanceOf
    {
      constant: true,

      inputs: [{ name: "_owner", type: "address" }],

      name: "balanceOf",

      outputs: [{ name: "balance", type: "uint256" }],

      type: "function",
    },
  ];

  let contract = new library.eth.Contract(minABI, address);
  const result = await contract.methods.balanceOf(account).call();

  return library.utils.fromWei(result);
};

export const sendSwapReceipt = async (receipt: any) => {
  try {
    const { data } = await axios.post(
      `http://ec2-18-224-40-44.us-east-2.compute.amazonaws.com/v1/bridge/swap`,
      receipt,
      { timeout: 120000 }
    );
    return data;
  } catch (error) {
    throw error;
  }
};

export const sendBurnReceipt = async (receipt: any) => {
  try {
    const { data } = await axios.post(
      `http://ec2-18-224-40-44.us-east-2.compute.amazonaws.com/v1/bridge/burn`,
      receipt
    );
    return data;
  } catch (error) {
    throw error;
  }
};
