import React from "react";
import Image from "next/image";
import { AiOutlineClose } from "react-icons/ai";

interface token {
  name: string;
  value: string;
  label: string;
  icon: string;
}

interface Props {
  tokens: token[];
  closeModal: React.Dispatch<React.SetStateAction<boolean>>;
  setToken: React.Dispatch<React.SetStateAction<string>>;
}

const SelectToken = ({ tokens, closeModal, setToken }: Props) => {
  return (
    <div className="flex justify-center items-center h-screen w-screen z-0 bg-modal">
      <div className=" w-full mx-4 lg:w-1/2 xl:w-[800px] h-auto bg-dark_purple shadow-md rounded-lg backdrop-blur-sm">
        <div className=" mx-8 py-10 flex flex-col">
          <div className="flex justify-between">
            <div className=" text-center text-lg font-bold ">
              Select a Token
            </div>
            <button
              onClick={() => closeModal(false)}
              className=" justify-self-end"
            >
              <AiOutlineClose fontSize={20} />
            </button>
          </div>
          <div>
            <input
              type="text"
              placeholder="Search token by name or address"
              className=" py-4 px-8 bg-dark rounded-3xl w-full mt-16 outline-none focus:outline-none "
            />
          </div>
          <div className=" flex flex-col mt-10">
            {tokens.map((token, i) => (
              <button
                key={`key-${i}`}
                onClick={() => {
                  setToken(token.value), closeModal(false);
                }}
                className=" flex items-center shadow-md bg-gradient-radial rounded-lg p-4 cursor-pointer mt-6"
              >
                <Image
                  src={token.icon}
                  alt={token.label}
                  height={30}
                  width={30}
                />
                <p className="ml-2">{token.label}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelectToken;
